---
date: Feb 27, 2015
---

1. Review a few of the things we've done so far. Which individual tasks have we pursued? *What do we now know how to do with texts? What do we not yet know how to do?* (Note: still need i/o, splitting text into lists of words, things like POS tagging; we know bigrams, word searches [manipulating strings].)

Maybe useful to actually run through the general structure of functions, five or so minutes

2. Turning code into reusable functions. Take the word search and bigram tagger and turn them into generalized functions. First should accept a list of words and a word to count and return (not print!) an integer counting the instances. Second should accept a list of words and generate a list of bigrams. Test both functions on the variable hm_words.

3. write a function that accepts a list of stopwords and removes 

3. and a half: Using some of the functions you've already written, write a program that accepts two lists of words, removes stopwords, and returns a list of all common bigrams. Which of these steps can we break into smaller functions? (Should make functions for removing stopwords and comparing elements in lists.)

4. If time: start thinking ahead to what functions we might write for future classes.



