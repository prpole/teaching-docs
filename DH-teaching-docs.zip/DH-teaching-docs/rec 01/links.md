*Links*:

	Cyberduck (Mac users):
	- https://cyberduck.io

	Mobaxterm (Windows users):
	- http://mobaxterm.mobatek.net/download.html

	Unix tutorial:  
	- http://www.columbia.edu/%7Elgw23/cs1004/

	Permissions:
	- http://www.columbia.edu/~pp2454/file_permissions.png
