Attendance:

Recitation attendance is worth 10% of the grade. 
There are 13 recitations in all (the one before spring break is canceled) 
1% for each recitation they attend up to 10%. This means:

	- They can miss up to 3 recitations penalty free
	- If they go to more than 10 recitations they still only get 10%
	- You must have a sign in sheet or take attendance or something so we can keep track.

Plan for today:

	- Install software
	- Practice navigating 
	- Log on to CUNIX
	- Practice transferring files through SFTP
	- Practice changing permissions
	- If we have time, install Python 3.4

Install:

	- Open links.md

Practice Navigating:

	- See Adam's handout for list of commands
	- have them make a folder for the recitation
	
Log on to CUNIX:

	- ssh UNI@cunix.columbia.edu
	- use navigation commands to see what's there
	- see how people feel about PICO, try to use it to make "example.txt"
	- try to navigate to it in browser; fail
	- use ls -l to see permissions
	- open public.md to see chmod commands and file_permissions.png to help navigate permissions
	- add read and execute access for others: chmod o+rx filename
	- navigate in web browser again, succeed.

Use Cyberduck and Mobaxterm as SFTP:

	- logut CUNIX
	- navigate to rec folder
	- make index.html, enter text inside <html> tags
	- Cyberduck, make connection; moba, start SSH session
	- transfer using GUI
	- login CUNIX, see that it's there
	- go in browser, see that it's there

Python:

	- got to python.org