#Review Concepts# (up to 20 minutes)

1. If statements, syntax
2. While loops, syntax
3. for loops, syntax
4. lists, index, slices; index, append, remove, pop (don't worry about the list[list.index(item)] stuff, do the basics and then create an exercise that will help them with that for next time)

#Word Search# (~ 30 min)

1. Have students download financier_load.py. Open it in IDLE. Run>Run Module (2 min)
2. Objective: write a program that counts the number of times the word "lobster" appears in this paragraph. 
    A. First pseudocode together (8 min)
    B. Break off to code, test (15 min)
    C. Solution in lobster_count.py
3. Generalize: what would we have to change to make this work for any word? (5 min)
    Solution: define a word variable and use it in place of 'lobster'

#Manipulating Lists# (probably won't get here until next week)

1. Objective: put all bigrams in list (bring up google ngram viewer to get bigram concept; also show on board the idea of a moving window)
2. Pseudocode together: difficult concepts = conditions of while loop and appending entries from one list onto another.
3. Break off to code, test. Solution in bigrams.py

