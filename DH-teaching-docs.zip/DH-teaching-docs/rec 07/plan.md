---
date: March 6, 2015
---
1. write a function that accepts a list of stopwords and removes 

2. Using some of the functions you've already written, write a program that accepts two lists of words, removes stopwords, and returns a list of all common bigrams. Which of these steps can we break into smaller functions? (Should make functions for removing stopwords and comparing elements in lists.)

4. Import first chapter of james; show splitting techniques; write program that splits words on whitespace and removes punctuation. Note that you have to use replace since strings are immutable.  



